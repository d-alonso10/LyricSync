import React, { useState, useEffect, useRef } from 'react';
import { MOCK_SONG } from './constants';
import LyricsView from './components/LyricsView';
import WindowControls from './components/WindowControls';

const App: React.FC = () => {
  // Start playing automatically for the "Lyrics Only" mode
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const requestRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const pausedTimeRef = useRef<number>(0);

  // Playback Loop Simulation
  const animate = (time: number) => {
    if (startTimeRef.current === 0) {
      startTimeRef.current = time;
    }
    
    // Calculate elapsed based on when we started relative to the paused timestamp
    const elapsed = (time - startTimeRef.current) / 1000 + pausedTimeRef.current;
    
    if (elapsed >= MOCK_SONG.duration) {
      setIsPlaying(false);
      setCurrentTime(MOCK_SONG.duration);
      return;
    }

    setCurrentTime(elapsed);
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    if (isPlaying) {
      // Reset start time so calculation is fresh from this moment
      startTimeRef.current = 0; 
      requestRef.current = requestAnimationFrame(animate);
    } else {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
      pausedTimeRef.current = currentTime;
    }

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying]);

  const handleSeek = (time: number) => {
    setCurrentTime(time);
    pausedTimeRef.current = time;
    startTimeRef.current = 0; // Reset animation frame reference
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  return (
    <div 
      className="h-screen w-screen text-white flex flex-col relative overflow-hidden transition-colors duration-1000 select-none app-draggable"
      onClick={togglePlay}
      style={{
        background: `linear-gradient(160deg, ${MOCK_SONG.colorStart} 0%, ${MOCK_SONG.colorEnd} 100%)`
      }}
    >
        {/* Simulated Window Controls (Mac/Linux Style) */}
        <WindowControls />

        {/* Dynamic Background Noise/Texture for "2025" feel */}
        <div className="absolute inset-0 opacity-20 pointer-events-none" 
             style={{ 
                 backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` 
             }} 
        />
        
        {/* Subtle Ambient Glow */}
        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-gradient-to-br from-white/10 to-transparent rounded-full blur-3xl opacity-30 animate-pulse pointer-events-none" />

        {/* Content Area - Full Screen Lyrics */}
        {/* We add 'no-drag' to interactable elements so dragging the window doesn't block clicks */}
        <div className="flex-1 flex flex-col relative z-10 overflow-hidden no-drag">
            <LyricsView 
                song={MOCK_SONG} 
                currentTime={currentTime} 
                onSeek={handleSeek} 
            />
        </div>
    </div>
  );
};

export default App;