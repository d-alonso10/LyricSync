import React from 'react';

const WindowControls: React.FC = () => {
  return (
    <div className="absolute top-0 left-0 p-4 z-50 flex gap-2 group no-drag">
      {/* 
        These buttons are visual representations of OS controls.
        In a real Electron app, these would hook into ipcRenderer to call window.close(), etc.
      */}
      <div className="flex gap-2 p-2 hover:bg-black/20 rounded-lg transition-colors cursor-default">
        {/* Close Button (Red) */}
        <div className="w-3 h-3 rounded-full bg-[#FF5F57] border border-[#E0443E] shadow-sm flex items-center justify-center overflow-hidden group/btn">
             <svg className="w-2 h-2 text-black/50 opacity-0 group-hover:opacity-100 group-hover/btn:opacity-100" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
             </svg>
        </div>
        
        {/* Minimize Button (Yellow) */}
        <div className="w-3 h-3 rounded-full bg-[#FEBC2E] border border-[#D89E24] shadow-sm flex items-center justify-center overflow-hidden group/btn">
             <svg className="w-2 h-2 text-black/50 opacity-0 group-hover:opacity-100 group-hover/btn:opacity-100" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                <line x1="5" y1="12" x2="19" y2="12"></line>
             </svg>
        </div>
        
        {/* Maximize Button (Green) */}
        <div className="w-3 h-3 rounded-full bg-[#28C840] border border-[#1AAB29] shadow-sm flex items-center justify-center overflow-hidden group/btn">
             <svg className="w-2 h-2 text-black/50 opacity-0 group-hover:opacity-100 group-hover/btn:opacity-100" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                <line x1="8" y1="12" x2="16" y2="12"></line>
                <line x1="12" y1="8" x2="12" y2="16"></line>
             </svg>
        </div>
      </div>
    </div>
  );
};

export default WindowControls;